const express = require('express');
const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// MongoDB connection URL
const url = 'mongodb://localhost:27017';
const dbName = 'web';
const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB
mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

fetch('/api/recipes')
    .then(response => response.json())
    .then(data => {
        RECIPES = data;
    })
    .catch(error => console.error('Error fetching recipes:', error));


app.get('/api/recipe/:id', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('recipes');
        const recipe = await collection.findOne({ p_id: req.params.id });
        res.json(recipe);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error fetching data from MongoDB');
    }
});


//ESQUEMA DE LA BASE DE DATOS
const recipeSchema = new mongoose.Schema({
    name: String,
    description: String,
    ingredients: String,
    codename: String,
    difficulty: String,
    likes: { type: Number, default: 0 }
  });

const Recipe = mongoose.model('Recipe', recipeSchema);

// FUNCION PARA OBTENER TODAS LAS RECETAS
app.get('/api/recipes', (req, res) => {
    Recipe.find()
      .then(recipes => res.json(recipes))
      .catch(err => res.status(400).send('Error: ' + err));
  });
  

//FUNCION PARA AÑADIR A LA BASE DE DATOS
app.post('/submit_recipe', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('recipes');
        const { name, description, ingredients, images, difficulty } = req.body;
        const newRecipe = {
            name,
            description,
            ingredients: ingredients.split(','),
            images: images.split(','),
            difficulty
        };
        await collection.insertOne(newRecipe);
        res.send('Recipe saved successfully!');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error saving recipe to MongoDB');
    }
});

// FUNCION PARA BORRAR DE LA BASE DE DATOS
app.post('/delete_recipe', (req, res) => {
    Recipe.findOneAndDelete({ name: req.body.delete_name })
      .then(() => res.send('Recipe deleted successfully'))
      .catch(err => res.status(400).send('Error: ' + err));
  });


// FUNCION PARA DAR LIKE A UNA RECETA
app.post('/like_recipe', (req, res) => {
    const recipeId = req.body.recipeId;
    Recipe.findByIdAndUpdate(recipeId, { $inc: { likes: 1 } }, { new: true })
      .then(updatedRecipe => res.json(updatedRecipe))
      .catch(err => res.status(400).send('Error: ' + err));
  });
  

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});