const SB = document.getElementById('searchBar');

const RECIPES = [];

document.addEventListener("DOMContentLoaded", function() {
    async function fetchRecipeData() {
        try {
            const response = await fetch('/api/recipes');
            const recipes = await response.json();
            RECIPES.push(...recipes);
            generateTiles(recipes);
        } catch (error) {
            console.error('Error fetching recipe data:', error);
        }
    }

    function generateTiles(recipes) {
        const tilesContainer = document.querySelector('.tiles');
        tilesContainer.innerHTML = ''; // Clear existing tiles

        recipes.forEach((recipe, index) => {
            const tile = document.createElement('article');
            tile.className = `style1${index + 1}`;
            tile.style.backgroundImage = `url('/css/images/${recipe.codename}.png')`;
    
            tile.innerHTML = `
                <span class="image">
                    <img src="images/${recipe.codename}.png" alt="" />
                </span>
                <a href="${recipe.link}">
                    <h2>${recipe.name}</h2>
                    <div class="content">
                        <img src="images/heart.png" width="32px" height="32px" style="float: left; margin-top: -0.15em; margin-right: 0.5em;">
                        <p style="margin: 0 0 0.5em 0; float: left;">${recipe.likes}</p>
                    </div>
                    <div class="content">
                        <img src="images/neutral.png" width="32px" height="32px" style="float: left; margin-top: -0.15em; margin-right: 0.5em;">
                        <p style="margin: 0 0 1em 0; float: left;">Difficulty <b>${recipe.difficulty}</b></p>
                    </div>
                </a>
            `;
    
            tilesContainer.appendChild(tile);
        });
    }

    fetchRecipeData();
});

SB.onclick = function() {
    SB.ariaPlaceholder = "";
    for (var i = 0; i < RECIPES.length; ++i) {
        document.getElementById(RECIPES[i].p_id).classList.add("fade");
    }
};

SB.onclick = function(){
    SB.ariaPlaceholder = "";
    for(var i=0; i<RECIPES.length; ++i){
        document.getElementById(RECIPES[i].p_id).classList.add("fade");
    }
    setTimeout(function(){
        for(var i=0; i<RECIPES.length; ++i){
            document.getElementById(RECIPES[i].p_id).classList.add("hidden");
        }
    },200);
};

SB.addEventListener('keyup', (e) => {
    const searchString = e.target.value;
    const filteredRecipes = RECIPES.filter(recipe => {
        return recipe.name.includes(searchString) || recipe.dif.includes(searchString) || recipe.ing.includes(searchString);
    });
    const unfilteredRecipes = RECIPES.filter(recipe => !filteredRecipes.includes(recipe));
    console.log(filteredRecipes);
    console.log(filteredRecipes.length);
    console.log(unfilteredRecipes);
    setTimeout(function(){
        for(var i=0;i<filteredRecipes.length;++i){
                    var style = document.getElementById(filteredRecipes[i].p_id);
                    style.classList.remove("hidden");
                    style.classList.remove("fade");
                    console.log(style);        
        }
        for(var i=0;i<unfilteredRecipes.length;++i){
            if(!document.getElementById(unfilteredRecipes[i].p_id).classList.contains("hidden")){
                document.getElementById(unfilteredRecipes[i].p_id).classList.add("hidden");
                console.log(style);
            }
        }
    },200);
});
